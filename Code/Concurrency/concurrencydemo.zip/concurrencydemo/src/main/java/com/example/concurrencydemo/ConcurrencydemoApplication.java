package com.example.concurrencydemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConcurrencydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConcurrencydemoApplication.class, args);
	}

}
